Directories here are:

engine     : global parameters
quad       : 4 patches
patch      : misc+sound+visual+effect
  misc
  sound
  visual
  effect
